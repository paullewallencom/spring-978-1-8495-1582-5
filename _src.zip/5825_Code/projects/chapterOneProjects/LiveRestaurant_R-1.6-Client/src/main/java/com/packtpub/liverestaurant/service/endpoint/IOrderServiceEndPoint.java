package com.packtpub.liverestaurant.service.endpoint;
/*
* This software is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND.
*/

public interface IOrderServiceEndPoint {
	  String invoke(String request) throws Exception;
}
