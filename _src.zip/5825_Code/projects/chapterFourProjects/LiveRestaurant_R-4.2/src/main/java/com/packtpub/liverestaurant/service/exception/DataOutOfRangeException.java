package com.packtpub.liverestaurant.service.exception;


public class DataOutOfRangeException extends Exception {
	public DataOutOfRangeException(String message) {
		super(message);
	}
}
